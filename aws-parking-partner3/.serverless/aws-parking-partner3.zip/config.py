    
    
class Config :
    JWT_SECRET_KEY = 'yhacademy1029##heelo'
    JWT_ACCESS_TOKEN_EXPIRES = False
    PROPAGATE_EXCEPTIONS = True
    ACCESS_KEY = 'AKIAVNZ2VTZUKDWLDIVS'
    SECRET_ACCESS = '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'
    # S3 버킷이름과, 기본 URL 주소 셋팅
    S3_BUCKET = 'kd-image-test'
    S3_LOCATION = 'https://kd-image-test.s3.amazonaws.com/'